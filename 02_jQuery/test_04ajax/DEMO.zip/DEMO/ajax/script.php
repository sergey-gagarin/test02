<?php
	unset($_GET["_"]);
?>
alert("Hi! I'm from a remote script");
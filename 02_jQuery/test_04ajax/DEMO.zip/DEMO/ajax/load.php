<a href="http://envato.com/" id="picture" target="_blank">
	<img src="http://envato.s3.amazonaws.com/Birthday2009/MainGraphic_200.jpg"></img>
</a>
<h2>Envato is 3!</h2>
<p>It was back in 2006 that Envato first launched with our very first site FlashDen. That means next week we’ll be turning 3 years old! Since web years are much like dog years, by my count that makes us pretty darn old. Given how we’ve grown, we’ve decided that this year it’s time we really kicked our celebrations up a notch. Next week for 3 days we’re going to have a massive sequence of birthday events, read on to find out what’s happening …</p>